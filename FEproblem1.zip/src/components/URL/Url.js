export const planetsUrl='https://findfalcone.herokuapp.com/planets'
export const VehiclesUrl='https://findfalcone.herokuapp.com/vehicles'
export const tokenUrl='https://findfalcone.herokuapp.com/token'
export const findUrl='https://findfalcone.herokuapp.com/find'